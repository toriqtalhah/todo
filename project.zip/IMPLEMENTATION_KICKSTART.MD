# Rewatt Landing Page — Implementation Kickstart

## Scope and status

This document is the approved implementation brief for a responsive, front-end-only Rewatt landing-page prototype. It is a plan, not an implementation: do not create application components or change the running app until implementation is separately authorized.

The prototype should explain the product and lead visitors to one conversion action: messaging Toriq Talhah on WhatsApp. Use examples where business details are not yet confirmed, and avoid presenting unverified outcomes as established facts.

## Product and messaging decisions

- **Product:** Rewatt uses room-installed devices with heat sensors to estimate how many people are in a room and detect whether lighting and air conditioning are on. An app provides room-level data and notifications. Technicians can use that information to decide whether to switch electronics off from their phone.
- **Do not claim:** guaranteed savings, verified performance, privacy protections, camera behavior, facial-recognition behavior, quiet-occupant accuracy, device reliability, compatibility with every site, or specific measured results. These claims have not been confirmed and are intentionally excluded.
- **Pricing explanation:** Describe the model as a fee equal to **30% of the savings Rewatt helps generate**, with an installation fee also applying. Do not state the installation-fee amount, invent a calculation or measurement methodology, or imply a guarantee. Keep wording clearly explanatory rather than contractual.
- **Contact:** Toriq Talhah. Use WhatsApp destination `https://wa.me/60196534965` with a URL-encoded prefilled inquiry. The supplied number `60+196534965` is normalized by removing the plus sign; confirm its digits and WhatsApp registration before launch.
- **Conversion rule:** One conversion action and destination, repeated at least three times in deliberate high-intent locations. The header, hero, pricing explanation, closing section, and footer may repeat it. Do not add competing CTAs or unrelated outbound links.
- **Prototype disclaimer:** FAQs and illustrative content can be placeholders and should be reviewed before production.

## Audience and content hierarchy

1. **Header:** Rewatt wordmark, compact navigation for in-page sections if useful, and a WhatsApp CTA. On smaller screens, use an accessible menu button and responsive menu; all menu items remain on-page anchors except the WhatsApp action.
2. **Hero:** State the operational problem and Rewatt’s room-level sensing/app workflow in plain language. Use one prominent WhatsApp CTA. Avoid guaranteed-savings language.
3. **Waste between sessions:** Explain that empty rooms may continue using air conditioning and lighting, and that manual checks can miss opportunities. Avoid blaming staff or occupants.
4. **How it works:** Show a simple three-step explanation: install the heat-sensing device; view occupancy and electronics status with room notifications in the app; let technicians decide whether to switch electronics off.
5. **Included in the program:** Present a clear, reusable feature grid for room occupancy and electronics status, app/dashboard notifications, site setup, and reporting. Phrase reporting as a product capability only to the extent it is confirmed; otherwise label it as an example or omit it.
6. **Pricing:** Explain the 30%-of-savings fee model and mention that an installation fee applies without stating its amount. Do not use a tier comparison, savings guarantee, savings claim, or unsupported verification promise. Include a WhatsApp CTA.
7. **Operational concerns:** Use concise, factual content about technician visibility and decision-making. Do not add privacy or sensing assurances that have not been validated.
8. **FAQ:** Use a single-column accessible accordion with prototype questions about installation, room data, app notifications, technician decisions, pricing, and site suitability. Avoid inventing specific technical guarantees; flag uncertain answers for review.
9. **Closing conversion band:** Invite operators to discuss their building or site with Toriq, with the same WhatsApp action.
10. **Footer:** Wordmark, concise product descriptor, Toriq Talhah contact, WhatsApp action, and appropriate copyright/location text only if confirmed.

## Visual direction and design tokens

Use a professional, operational-energy visual identity: confident green as the primary brand color, warm neutral surfaces, deep ink for readable text, and restrained amber for secondary highlights. Use glass effects on selected cards as a visual treatment, not as the sole source of contrast or hierarchy. Reassess contrast after implementation; glass surfaces must remain legible over their backgrounds.

Suggested initial tokens (validate in the rendered UI):

| Token | Initial value | Use |
|---|---|---|
| `--brand` | `#167A55` | Primary brand and CTA surface |
| `--brand-strong` | `#105B40` | Hover/pressed states and strong accents |
| `--brand-soft` | `#E6F3EC` | Tinted panels and supporting surfaces |
| `--ink` | `#17231D` | Primary text |
| `--muted` | `#5D6B63` | Supporting text; validate contrast on each surface |
| `--surface` | `#F7F8F4` | Page background |
| `--surface-raised` | `rgba(255,255,255,0.76)` | Glass card fill, with a solid-color fallback |
| `--line` | `rgba(23,35,29,0.12)` | Borders and dividers |
| `--highlight` | `#D49A42` | Small, non-essential emphasis |
| `--focus` | `#146B4B` | Visible keyboard focus indicator |

Use semantic CSS variables and map them into the existing Tailwind/shadcn token conventions rather than scattering raw colors through components. Glass cards should combine a translucent fill, subtle border, restrained shadow, and backdrop blur, with a readable fallback where blur is unsupported. Verify text and control contrast; do not assume transparency passes accessibility requirements.

### Typography

Prefer Geist for the interface. Use the existing project font setup if available; otherwise use the supported Geist/Geist Sans font integration rather than introducing an unnecessary second family. Establish a clear scale for display heading, section heading, body, and small labels. Keep body copy comfortably readable and avoid relying on muted color alone to indicate secondary importance.

## Responsive behavior and interaction

- Design mobile-first, then adapt to tablet and desktop. Check narrow phone, wide phone, tablet portrait/landscape, and desktop layouts.
- Use flexible containers, responsive grid changes, readable line lengths, and touch targets suitable for mobile.
- Ensure header navigation collapses cleanly. The mobile menu button must expose its expanded state, have an accessible name, work by keyboard, and not obscure content.
- Use subtle entrance/reveal transitions and restrained hover/focus feedback. Avoid motion that delays access to content or distracts from the message.
- Respect `prefers-reduced-motion`; disable or reduce non-essential animation and smooth scrolling when requested.
- Keep the page usable without JavaScript-dependent animation. Provide visible focus styles and semantic landmarks.
- Use a working in-page accordion with accessible controls and appropriate expanded state. No application-level state-management library is needed; local component state is sufficient only where interaction requires it.
- Reuse lucide-react icons where they improve scanability. Do not use icons as the only labels for important actions.
- Generate real visual assets only if they add useful product context; otherwise prefer a polished CSS-led layout over decorative placeholders. Any temporary images must be replaceable without redesigning the page.

## Component and file organization

Build the landing page from small, cohesive components and data-driven repeated content. Keep files around 600 lines or fewer, preferably substantially shorter. Suggested boundaries:

- page composition and metadata
- header/navigation and mobile menu
- reusable WhatsApp CTA/link
- hero and content sections
- feature/process cards
- pricing explanation
- FAQ accordion
- closing CTA and footer
- shared types/content data and styles only where consistent with the existing project

Inspect the existing Next.js, Tailwind, shadcn, and icon setup before implementation. Reuse installed components and project conventions; do not replace scaffold files unnecessarily. Avoid adding a state-management library or backend for this front-end prototype.

## WhatsApp destination and message

Use one shared destination constant so every CTA uses identical contact details and message text. Construct the link with `URLSearchParams` or an equivalent safe URL-encoding approach. Suggested message:

> Hi Toriq, I’d like to learn more about Rewatt for our site. Building/Space: [Building/Space Name]. Location: [Location]. Approximate number of rooms/halls: [Number].

Use `https://wa.me/60196534965?text=...` after confirming the normalized number. Use a real anchor with a descriptive accessible name. Decide whether to open WhatsApp in a new tab consistently; if using a new tab, include appropriate `rel` attributes.

## SEO and metadata

- Set a concise, descriptive page title and meta description focused on Rewatt, room occupancy/electronics monitoring, and campus/commercial facilities.
- Use one descriptive H1 and a logical heading hierarchy. Keep meaningful content as text rather than embedding it in images.
- Add canonical/social metadata only when the production domain and brand assets are known. Do not invent a canonical URL or Open Graph image.
- Use descriptive link text, appropriate image alt text, and avoid unsupported structured data or performance claims.
- Add baseline response security headers in the existing Next.js configuration where compatible with the project. Do not add a restrictive CSP without understanding the app’s required sources and preview behavior.

## Validation and acceptance checklist

- [ ] Every CTA and WhatsApp link goes to Toriq’s one shared prefilled WhatsApp destination; no competing conversion route exists.
- [ ] The normalized number is confirmed as correct and registered on WhatsApp before production use.
- [ ] Copy accurately describes heat-sensor occupancy detection, room-level electronics status, app notifications, and technician choice to switch electronics off.
- [ ] Pricing explains the 30% savings-based fee and that an installation fee applies, without stating its amount or inventing contractual terms.
- [ ] No guarantee, measured savings evidence, privacy assurance, or unverified technical promise appears.
- [ ] FAQ content is clearly treated as prototype copy and avoids unsupported claims.
- [ ] Layout is reviewed at mobile, tablet, and desktop viewports; no overflow, clipped text, or unusable navigation.
- [ ] Color contrast is checked for text, buttons, focus states, and translucent card surfaces; glass effects have a legible fallback.
- [ ] Keyboard navigation, accordion semantics, mobile menu state, and reduced-motion behavior are checked.
- [ ] Metadata is appropriate and does not invent a live domain or unverified claims.
- [ ] User-visible copy and links are verified in the running preview before release.

## Open items before production

1. Confirm the WhatsApp number’s exact international format and that it is the intended business contact.
2. Confirm what the app reports and what the technician can actually control; retain cautious wording until verified.
3. Confirm whether the 30% fee is calculated from gross or net savings, how savings are determined, and how the installation fee is described in formal terms. Keep these details out of the prototype unless approved.
4. Confirm whether monthly reports, room calibration, and end-to-end installation are actual included services before presenting them as definite inclusions.
5. Replace placeholder FAQ answers, contact/location details, and any sample brand imagery with approved production content.
