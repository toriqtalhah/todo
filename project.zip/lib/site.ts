export const site = {
  name: 'Rewatt',
  title: 'Rewatt — Stop cooling and lighting empty rooms',
  description:
    'Rewatt uses heat sensors to detect room occupancy, lighting and air conditioning, then alerts your technicians in the app so they can switch off what is not needed. You pay 30% of what you save.',
  locale: 'en_MY',
  contactName: 'Toriq Talhah',
  whatsappNumber: '60196534965',
  whatsappDisplay: '+60 19-653 4965',
} as const

const whatsappMessage = [
  "Hi Toriq, I'd like to learn more about Rewatt for our site.",
  'Building/Space: [Building/Space Name]',
  'Location: [Location]',
  'Approximate number of rooms/halls: [Number]',
].join('\n')

export const whatsappHref = `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`

export const navLinks = [
  { href: '#how-it-works', label: 'How it works' },
  { href: '#features', label: 'Features' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#faq', label: 'FAQ' },
] as const
