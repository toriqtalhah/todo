import {
  AirVent,
  BellRing,
  Lightbulb,
  Smartphone,
  Thermometer,
  Users,
  Wrench,
  Building2,
  Clock,
  Eye,
  Hand,
  type LucideIcon,
} from 'lucide-react'

export type IconItem = {
  icon: LucideIcon
  title: string
  description: string
}

export const problemPoints: IconItem[] = [
  {
    icon: AirVent,
    title: 'Air conditioning keeps running',
    description:
      'Classes end, meetings wrap up, and the AC often keeps cooling a room nobody is using.',
  },
  {
    icon: Lightbulb,
    title: 'Lights stay on between sessions',
    description:
      'Rooms that are booked back-to-back one hour can sit empty and fully lit the next.',
  },
  {
    icon: Clock,
    title: 'Manual checks can’t cover every room',
    description:
      'Walking the building takes time, and it is easy to miss rooms on a busy day.',
  },
]

export const steps: IconItem[] = [
  {
    icon: Thermometer,
    title: 'Install Rewatt in each room',
    description:
      'A compact heat-sensing device is installed in the rooms and halls you want to monitor.',
  },
  {
    icon: Smartphone,
    title: 'See every room in the app',
    description:
      'The app shows how many people are in each room and whether lights and AC are on, with notifications per room.',
  },
  {
    icon: Hand,
    title: 'Your technicians decide',
    description:
      'When a room is empty but still running, technicians can choose to switch the electronics off from their phone.',
  },
]

export const features: IconItem[] = [
  {
    icon: Users,
    title: 'Room occupancy',
    description: 'Heat sensors estimate how many people are inside each room.',
  },
  {
    icon: Lightbulb,
    title: 'Lights & AC status',
    description: 'Know at a glance whether lighting and air conditioning are on.',
  },
  {
    icon: BellRing,
    title: 'Room notifications',
    description: 'Get notified about each room Rewatt is installed in.',
  },
  {
    icon: Smartphone,
    title: 'Control from your phone',
    description: 'Technicians can switch electronics off remotely when they choose to.',
  },
  {
    icon: Wrench,
    title: 'Site setup',
    description: 'We work with your team to set Rewatt up across your rooms and halls.',
  },
  {
    icon: Building2,
    title: 'Built for many rooms',
    description: 'Designed for campuses, offices and facilities with lots of spaces.',
  },
]

export const teamPoints: IconItem[] = [
  {
    icon: Eye,
    title: 'Visibility, not guesswork',
    description:
      'Technicians see which rooms are occupied and what is running before deciding what to do.',
  },
  {
    icon: Hand,
    title: 'People stay in control',
    description:
      'Rewatt informs your team. Switching electronics off remains their call, room by room.',
  },
  {
    icon: BellRing,
    title: 'Fewer rounds on foot',
    description:
      'Notifications point technicians to the rooms that need attention instead of checking them all.',
  },
]

export const pricingSteps = [
  {
    title: 'Installation fee',
    description: 'A one-time installation fee applies when Rewatt is set up at your site.',
  },
  {
    title: 'You start saving',
    description: 'Your team uses Rewatt to switch off electronics in empty rooms.',
  },
  {
    title: 'We share the savings',
    description: 'Our fee is 30% of the money Rewatt helps you save. You keep the other 70%.',
  },
] as const

// Prototype copy: answers to be reviewed before production.
export const faqs = [
  {
    question: 'How does Rewatt know if a room is occupied?',
    answer:
      'Rewatt uses heat sensors to detect how many people are inside a room. It also detects whether the lights and air conditioners are turned on.',
  },
  {
    question: 'What does the installation involve?',
    answer:
      'A Rewatt device is installed in each room you want to monitor. We will walk through your rooms and halls with you before installation.',
  },
  {
    question: 'What will I see in the app?',
    answer:
      'The app shows room data and sends notifications for each room Rewatt is installed in, so technicians know where electronics are running.',
  },
  {
    question: 'Does Rewatt switch things off automatically?',
    answer:
      'Rewatt gives your technicians the information and access. They decide whether to switch the electronics off from their phone.',
  },
  {
    question: 'How is pricing calculated?',
    answer:
      'An installation fee applies, and our ongoing fee is 30% of the money Rewatt helps you save. Message Toriq to talk through how this works for your site.',
  },
  {
    question: 'Is Rewatt right for my building?',
    answer:
      'Rewatt is designed for sites with many rooms, such as campuses and offices. The best way to find out is to message Toriq with a few details about your site.',
  },
] as const
