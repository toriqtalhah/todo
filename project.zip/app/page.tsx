import { SiteHeader } from '@/components/landing/site-header'
import { Hero } from '@/components/landing/hero'
import {
  FeaturesSection,
  HowItWorksSection,
  ProblemSection,
  TeamSection,
} from '@/components/landing/info-sections'
import { PricingSection } from '@/components/landing/pricing-section'
import { FaqSection } from '@/components/landing/faq-section'
import { ClosingCta, SiteFooter } from '@/components/landing/closing-footer'

export default function Page() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[60] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <SiteHeader />
      <main id="main">
        <Hero />
        <ProblemSection />
        <HowItWorksSection />
        <FeaturesSection />
        <PricingSection />
        <TeamSection />
        <FaqSection />
        <ClosingCta />
      </main>
      <SiteFooter />
    </>
  )
}
