import { navLinks, site } from '@/lib/site'
import { Wordmark } from './primitives'
import { WhatsAppCta } from './whatsapp-cta'

export function ClosingCta() {
  return (
    <section aria-labelledby="closing-title" className="px-5 pb-20 md:px-8 md:pb-28">
      <div className="reveal relative mx-auto max-w-6xl overflow-hidden rounded-3xl bg-brand-deep px-6 py-16 text-center sm:px-12 md:py-20">
        <div aria-hidden="true" className="bg-orbs-dark" />
        <div className="relative mx-auto flex max-w-2xl flex-col items-center gap-6">
          <h2 id="closing-title" className="text-3xl font-semibold tracking-tight text-balance text-white md:text-5xl">
            Let&apos;s look at your rooms together
          </h2>
          <p className="text-lg leading-relaxed text-pretty text-white/80">
            Tell Toriq about your building, where it is, and roughly how many rooms or halls you have.
            He&apos;ll walk you through how Rewatt could work for your site.
          </p>
          <WhatsAppCta variant="inverse" size="lg" />
        </div>
      </div>
    </section>
  )
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-10 px-5 py-12 md:flex-row md:justify-between md:px-8">
        <div className="flex max-w-sm flex-col gap-3">
          <Wordmark />
          <p className="leading-relaxed text-muted-foreground">
            Room-level occupancy and electronics monitoring for campuses, offices and facilities.
          </p>
        </div>

        <nav aria-label="Footer">
          <h2 className="text-sm font-semibold text-foreground">Explore</h2>
          <ul className="mt-3 flex flex-col gap-2">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-muted-foreground transition-colors hover:text-primary">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex flex-col items-start gap-3">
          <h2 className="text-sm font-semibold text-foreground">Contact</h2>
          <p className="text-muted-foreground">
            {site.contactName}
            <br />
            {site.whatsappDisplay}
          </p>
          <WhatsAppCta size="sm" variant="outline" label="Start a conversation" />
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto w-full max-w-6xl px-5 py-6 text-sm text-muted-foreground md:px-8">
          &copy; {new Date().getFullYear()} {site.name}. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
