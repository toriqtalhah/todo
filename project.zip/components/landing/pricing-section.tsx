import { pricingSteps } from '@/lib/content'
import { Section, SectionHeading } from './primitives'
import { WhatsAppCta } from './whatsapp-cta'

export function PricingSection() {
  return (
    <Section id="pricing" labelledBy="pricing-title" className="bg-brand-soft/60">
      <SectionHeading
        id="pricing-title"
        eyebrow="Pricing"
        title="You only pay from what you save"
        description="No tiers or subscriptions to compare. Our fee is tied to the savings Rewatt helps you achieve."
      />

      <div className="glass-strong reveal mx-auto mt-14 grid max-w-5xl gap-10 rounded-3xl p-6 sm:p-10 lg:grid-cols-[1fr_1.1fr] lg:items-center">
        <div className="flex flex-col gap-6">
          <div>
            <p className="text-7xl font-semibold tracking-tight text-primary md:text-8xl">30%</p>
            <p className="mt-2 text-xl font-medium text-foreground">of the money you save</p>
          </div>

          <div aria-hidden="true" className="flex flex-col gap-2">
            <div className="flex h-4 overflow-hidden rounded-full bg-white/70">
              <div className="w-[70%] bg-primary" />
              <div className="w-[30%] bg-highlight" />
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>You keep 70%</span>
              <span>Rewatt fee 30%</span>
            </div>
          </div>
          <p className="sr-only">From every amount saved, you keep 70% and Rewatt&apos;s fee is 30%.</p>

          <WhatsAppCta label="Discuss the pricing" className="self-start" />
        </div>

        <ol className="flex flex-col gap-4">
          {pricingSteps.map((step, index) => (
            <li key={step.title} className="flex gap-4 rounded-2xl bg-white/60 p-5">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-primary font-mono text-sm font-semibold text-primary-foreground">
                {index + 1}
              </span>
              <div>
                <h3 className="font-semibold text-foreground">{step.title}</h3>
                <p className="mt-1 leading-relaxed text-muted-foreground">{step.description}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </Section>
  )
}
