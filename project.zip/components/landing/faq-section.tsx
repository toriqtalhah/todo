import { ChevronDown } from 'lucide-react'
import { faqs } from '@/lib/content'
import { Section, SectionHeading } from './primitives'

export function FaqSection() {
  return (
    <Section id="faq" labelledBy="faq-title">
      <SectionHeading id="faq-title" eyebrow="FAQ" title="Questions, answered" />
      <div className="mx-auto mt-12 flex max-w-3xl flex-col gap-3">
        {faqs.map((faq) => (
          <details key={faq.question} className="glass reveal group rounded-2xl">
            <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 rounded-2xl px-6 py-4 text-left font-medium text-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring [&::-webkit-details-marker]:hidden">
              {faq.question}
              <ChevronDown
                aria-hidden="true"
                className="size-5 shrink-0 text-primary transition-transform duration-300 group-open:rotate-180"
              />
            </summary>
            <p className="px-6 pb-5 leading-relaxed text-muted-foreground">{faq.answer}</p>
          </details>
        ))}
      </div>
    </Section>
  )
}
