import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'
import type { IconItem } from '@/lib/content'

type SectionProps = {
  id?: string
  className?: string
  children: ReactNode
  labelledBy?: string
}

export function Section({ id, className, children, labelledBy }: SectionProps) {
  return (
    <section
      id={id}
      aria-labelledby={labelledBy}
      className={cn('relative py-20 md:py-28', className)}
    >
      <div className="mx-auto w-full max-w-6xl px-5 md:px-8">{children}</div>
    </section>
  )
}

type SectionHeadingProps = {
  id: string
  eyebrow: string
  title: ReactNode
  description?: ReactNode
  align?: 'left' | 'center'
  tone?: 'default' | 'inverse'
}

export function SectionHeading({
  id,
  eyebrow,
  title,
  description,
  align = 'center',
  tone = 'default',
}: SectionHeadingProps) {
  const inverse = tone === 'inverse'
  return (
    <div
      className={cn(
        'reveal flex max-w-2xl flex-col gap-4',
        align === 'center' && 'mx-auto items-center text-center',
      )}
    >
      <p
        className={cn(
          'text-sm font-semibold tracking-wide uppercase',
          inverse ? 'text-brand-soft' : 'text-primary',
        )}
      >
        {eyebrow}
      </p>
      <h2
        id={id}
        className={cn(
          'text-3xl font-semibold tracking-tight text-balance md:text-4xl lg:text-5xl',
          inverse ? 'text-white' : 'text-foreground',
        )}
      >
        {title}
      </h2>
      {description ? (
        <p
          className={cn(
            'text-lg leading-relaxed text-pretty',
            inverse ? 'text-white/80' : 'text-muted-foreground',
          )}
        >
          {description}
        </p>
      ) : null}
    </div>
  )
}

type IconCardProps = IconItem & {
  index?: number
  className?: string
}

export function IconCard({ icon: Icon, title, description, index, className }: IconCardProps) {
  return (
    <article
      className={cn(
        'glass reveal group flex flex-col gap-4 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl motion-reduce:hover:translate-y-0',
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <span className="flex size-12 items-center justify-center rounded-xl bg-brand-soft text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
          <Icon aria-hidden="true" className="size-6" />
        </span>
        {typeof index === 'number' ? (
          <span className="font-mono text-sm text-muted-foreground" aria-hidden="true">
            {String(index + 1).padStart(2, '0')}
          </span>
        ) : null}
      </div>
      <h3 className="text-lg font-semibold text-foreground">{title}</h3>
      <p className="leading-relaxed text-muted-foreground">{description}</p>
    </article>
  )
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-2 text-xl font-semibold tracking-tight', className)}>
      <span
        aria-hidden="true"
        className="flex size-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground"
      >
        R
      </span>
      Rewatt
    </span>
  )
}
