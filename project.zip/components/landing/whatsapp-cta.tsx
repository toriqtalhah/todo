import { MessageCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import { whatsappHref } from '@/lib/site'

const variants = {
  primary:
    'bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:bg-brand-strong',
  outline:
    'glass text-foreground hover:border-primary/40 hover:text-brand-strong',
  inverse: 'bg-white text-brand-strong shadow-lg shadow-black/20 hover:bg-brand-soft',
} as const

const sizes = {
  sm: 'h-10 px-4 text-sm gap-2',
  md: 'h-12 px-6 text-base gap-2.5',
  lg: 'h-14 px-7 text-base md:text-lg gap-3',
} as const

type WhatsAppCtaProps = {
  label?: string
  variant?: keyof typeof variants
  size?: keyof typeof sizes
  className?: string
}

export function WhatsAppCta({
  label = 'Discuss Rewatt for your site',
  variant = 'primary',
  size = 'md',
  className,
}: WhatsAppCtaProps) {
  return (
    <a
      href={whatsappHref}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        'group inline-flex items-center justify-center rounded-full font-medium whitespace-nowrap transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring motion-reduce:transition-none motion-reduce:hover:translate-y-0',
        variants[variant],
        sizes[size],
        className,
      )}
    >
      <MessageCircle
        aria-hidden="true"
        className="size-[1.15em] transition-transform duration-300 group-hover:scale-110"
      />
      <span>{label}</span>
      <span className="sr-only"> (opens WhatsApp in a new tab)</span>
    </a>
  )
}
