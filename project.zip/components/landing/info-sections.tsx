import { features, problemPoints, steps, teamPoints } from '@/lib/content'
import { IconCard, Section, SectionHeading } from './primitives'

export function ProblemSection() {
  return (
    <Section labelledBy="problem-title" className="bg-brand-soft/60">
      <SectionHeading
        id="problem-title"
        eyebrow="The hidden cost"
        title="Empty rooms still use energy"
        description="Between classes, meetings and events, air conditioning and lighting can keep running in rooms nobody is using."
      />
      <div className="mt-14 grid gap-5 md:grid-cols-3">
        {problemPoints.map((item) => (
          <IconCard key={item.title} {...item} />
        ))}
      </div>
    </Section>
  )
}

export function HowItWorksSection() {
  return (
    <Section id="how-it-works" labelledBy="how-title">
      <SectionHeading
        id="how-title"
        eyebrow="How it works"
        title="Sense the room. Notify the team. Switch off."
        description="Three simple steps from installation to action."
      />
      <ol className="relative mt-14 grid gap-5 md:grid-cols-3">
        <div
          aria-hidden="true"
          className="absolute top-12 right-[16%] left-[16%] hidden h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent md:block"
        />
        {steps.map((step, index) => (
          <li key={step.title} className="relative">
            <IconCard {...step} index={index} className="h-full" />
          </li>
        ))}
      </ol>
    </Section>
  )
}

export function FeaturesSection() {
  return (
    <Section id="features" labelledBy="features-title" className="overflow-hidden">
      <div aria-hidden="true" className="bg-orbs opacity-70" />
      <SectionHeading
        id="features-title"
        eyebrow="What you get"
        title="Everything your team needs to act on empty rooms"
      />
      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((item) => (
          <IconCard key={item.title} {...item} />
        ))}
      </div>
    </Section>
  )
}

export function TeamSection() {
  return (
    <Section labelledBy="team-title">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:items-center">
        <SectionHeading
          id="team-title"
          align="left"
          eyebrow="For facilities teams"
          title="Made for the people who run the building"
          description="Rewatt gives technicians a clear view of every room, so they can spend less time checking and more time acting."
        />
        <div className="grid gap-4">
          {teamPoints.map((item) => (
            <IconCard key={item.title} {...item} />
          ))}
        </div>
      </div>
    </Section>
  )
}
