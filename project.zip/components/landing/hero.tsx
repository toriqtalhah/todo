import Image from 'next/image'
import { AirVent, ArrowDown, BellRing, Lightbulb, Users } from 'lucide-react'
import { WhatsAppCta } from './whatsapp-cta'

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="hero-section relative isolate overflow-hidden pt-10 pb-20 md:pt-16 md:pb-28">
      <div aria-hidden="true" className="hero-motion">
        <span className="hero-glow hero-glow-green" />
        <span className="hero-glow hero-glow-gold" />
        <span className="hero-orbit" />
        <span className="hero-orbit hero-orbit-inner" />
        <span className="hero-sensor-pulse" />
      </div>
      <div className="relative z-10 mx-auto grid w-full max-w-6xl items-center gap-12 px-5 md:px-8 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
        <div className="flex flex-col items-start gap-6 motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-bottom-6 motion-safe:duration-700">
          <p className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium text-brand-strong">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full rounded-full bg-primary opacity-60 motion-safe:animate-ping" />
              <span className="relative inline-flex size-2 rounded-full bg-primary" />
            </span>
            Room-level energy monitoring
          </p>
          <h1
            id="hero-title"
            className="text-4xl leading-[1.05] font-semibold tracking-tight text-balance text-foreground sm:text-5xl lg:text-6xl"
          >
            Stop paying to cool and light <span className="text-primary">empty rooms.</span>
          </h1>
          <p className="max-w-xl text-lg leading-relaxed text-pretty text-muted-foreground md:text-xl">
            Rewatt&apos;s heat sensors detect how many people are in a room and whether the lights and
            air conditioning are on. Your technicians get room-by-room updates in the app and decide
            what to switch off, right from their phone.
          </p>
          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:items-center">
            <WhatsAppCta size="lg" label="Explore Rewatt for your site" />
            <a
              href="#how-it-works"
              className="inline-flex h-14 items-center justify-center gap-2 rounded-full px-6 font-medium text-foreground transition-colors hover:text-primary"
            >
              See how it works
              <ArrowDown aria-hidden="true" className="size-4" />
            </a>
          </div>
          <p className="text-sm text-muted-foreground">
            You pay 30% of what you save, plus an installation fee.
          </p>
        </div>

        <HeroVisual />
      </div>
    </section>
  )
}

function HeroVisual() {
  return (
    <div className="relative motion-safe:animate-in motion-safe:fade-in motion-safe:zoom-in-95 motion-safe:duration-1000">
      <div className="relative aspect-[4/5] overflow-hidden rounded-3xl shadow-2xl shadow-ink/15 sm:aspect-[4/3] lg:aspect-[4/5]">
        <Image
          src="/images/hero-lecture-hall.png"
          alt="An empty lecture hall with the lights and air conditioning still running"
          fill
          priority
          sizes="(min-width: 1024px) 45vw, 100vw"
          className="object-cover"
        />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-ink/50 via-transparent to-transparent" />
      </div>

      <div
        aria-hidden="true"
        className="glass-strong absolute right-4 bottom-4 left-4 rounded-2xl p-4 sm:right-auto sm:left-6 sm:bottom-6 sm:w-80 motion-safe:animate-float"
      >
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold text-foreground">Lecture Hall B</p>
          <span className="rounded-full bg-highlight/20 px-2.5 py-0.5 text-xs font-medium text-ink">
            Needs attention
          </span>
        </div>
        <ul className="mt-3 grid grid-cols-3 gap-2 text-center">
          <Stat icon={<Users className="size-4" />} label="People" value="0" />
          <Stat icon={<Lightbulb className="size-4" />} label="Lights" value="On" />
          <Stat icon={<AirVent className="size-4" />} label="AC" value="On" />
        </ul>
      </div>

      <div
        aria-hidden="true"
        className="glass-strong absolute -top-4 right-4 hidden items-center gap-3 rounded-2xl px-4 py-3 sm:flex md:-right-4"
      >
        <span className="flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
          <BellRing className="size-4" />
        </span>
        <div>
          <p className="text-sm font-semibold text-foreground">Room empty for 20 min</p>
          <p className="text-xs text-muted-foreground">Switch off electronics?</p>
        </div>
      </div>
    </div>
  )
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <li className="flex flex-col items-center gap-1 rounded-xl bg-white/60 px-2 py-2">
      <span className="text-primary">{icon}</span>
      <span className="text-base font-semibold text-foreground">{value}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
    </li>
  )
}
